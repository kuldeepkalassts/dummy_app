package com.pcloudy.pcloudydemo;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button viewall=(Button) findViewById(R.id.viewall);
        viewall.setTextColor(Color.RED);
        viewall.setBackgroundColor(Color.WHITE);

        TextView txtmobile = (TextView)findViewById(R.id.txtmobile);

        TextView txtphone = (TextView)findViewById(R.id.txtphone);

        TextView txtinternet = (TextView)findViewById(R.id.txtinternet);

        TextView txtdatacard = (TextView)findViewById(R.id.txtdatacard);


        TextView txtlocation = (TextView)findViewById(R.id.txtlocation);

        TextView txtnetwork = (TextView)findViewById(R.id.txtnetwork);

        TextView txtwallet = (TextView)findViewById(R.id.txtwallet);

        TextView txtshare = (TextView)findViewById(R.id.txtshare);


        txtmobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Mobile.class);
                startActivity(i);

            }
        });


        txtphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Phone.class);
                startActivity(i);

            }
        });




        txtinternet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Internet.class);
                startActivity(i);

            }
        });


        txtdatacard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, DataCard.class);
                startActivity(i);

            }
        });



        txtlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Location.class);
                startActivity(i);

            }
        });


        txtnetwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Wifi.class);
                startActivity(i);

            }
        });


        txtwallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Wallet.class);
                startActivity(i);

            }
        });


        txtshare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Share.class);
                startActivity(i);

            }
        });









        ImageView imobile = (ImageView)findViewById(R.id.imobile);
        ImageView iphone = (ImageView)findViewById(R.id.iphone);
        ImageView iinternet = (ImageView)findViewById(R.id.iinternet);
        ImageView idatacard = (ImageView)findViewById(R.id.idatacard);
        ImageView ilocation = (ImageView)findViewById(R.id.ilocation);
        ImageView iwifi = (ImageView)findViewById(R.id.iwifi);
        ImageView iwallet = (ImageView)findViewById(R.id.iwallet);
        ImageView ishare = (ImageView)findViewById(R.id.ishare);


        ImageView first = (ImageView)findViewById(R.id.first_h);
        ImageView second = (ImageView)findViewById(R.id.imgsecond);
        ImageView third = (ImageView)findViewById(R.id.imgthird);
        ImageView fourth = (ImageView)findViewById(R.id.imgfour);

        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, one.class);
                startActivity(i);

            }
        });

//        second.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Log.d("View ","View all click" );
//
//                Intent i = new Intent(MainActivity.this, Second.class);
//                startActivity(i);
//
//            }
//        });


//        third.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Log.d("View ","View all click" );
//
//                Intent i = new Intent(MainActivity.this, Third.class);
//                startActivity(i);
//
//            }
//        });

        fourth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, Four.class);
                startActivity(i);

            }
        });


        imobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Mobile.class);
                startActivity(i);
            }
        });




        iphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, PhoneAct.class);
                startActivity(i);

            }
        });


        iinternet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Internet.class);
                startActivity(i);
            }
        });


        idatacard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, DataCard.class);
                startActivity(i);
            }
        });



        ilocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("View ","View all click" );
                Intent i = new Intent(MainActivity.this, Location.class);
                startActivity(i);
            }
        });


        iwifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, Wifi.class);
                startActivity(i);

            }
        });


        iwallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, Wallet.class);
                startActivity(i);

            }
        });



        ishare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, Share.class);
                startActivity(i);

            }
        });


        viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );

                Intent i = new Intent(MainActivity.this, ViewallActivity.class);
                startActivity(i);
            }
        });


//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.home) {

        } else if (id == R.id.mobile) {

            Intent i = new Intent(MainActivity.this, Mobile.class);
            startActivity(i);



        } else if (id == R.id.internet) {

            Intent i = new Intent(MainActivity.this, Internet.class);
            startActivity(i);


        } else if (id == R.id.broadband) {

            Intent i = new Intent(MainActivity.this, DataCard.class);
            startActivity(i);
        } else if (id == R.id.location) {


            Intent i = new Intent(MainActivity.this, Location.class);
            startActivity(i);


        } else if (id == R.id.network) {


            Log.d("View ","View all click" );

            Intent i = new Intent(MainActivity.this, Wifi.class);
            startActivity(i);

        } else if (id == R.id.wallet) {

            Intent i = new Intent(MainActivity.this, Wallet.class);
            startActivity(i);

        } else if (id == R.id.share) {

            Intent i = new Intent(MainActivity.this, Share.class);
            startActivity(i);

        }




        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
