package com.pcloudy.pcloudydemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewallActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewall);

//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//
//        toolbar.setTitle("pcloudyDemo App");
//
//        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
//            }
//        });




        TextView txtone = (TextView)findViewById(R.id.txtone);
        TextView txttwo = (TextView)findViewById(R.id.txttwo2);

        TextView txtthree = (TextView)findViewById(R.id.txtthree);

        TextView txtfour = (TextView)findViewById(R.id.txtfour);

        TextView txtfive = (TextView)findViewById(R.id.txtfive);

        TextView txtsix = (TextView)findViewById(R.id.txtsix);

        TextView txtseven = (TextView)findViewById(R.id.txtseven);

        TextView txteight = (TextView)findViewById(R.id.txteight1);

        TextView txtnine = (TextView)findViewById(R.id.txtnine1);


        TextView txtten = (TextView)findViewById(R.id.txtten1);

        TextView txteleven = (TextView)findViewById(R.id.txteleven);
        TextView txttwelve = (TextView)findViewById(R.id.txttwelve);
        TextView txtthirteen = (TextView)findViewById(R.id.txtthirteen);

        txtone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, one.class);
                startActivity(i);
            }
        });


        txttwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Second.class);
                startActivity(i);
            }
        });

        txtthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Third.class);
                startActivity(i);
            }
        });


        txtfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Four.class);
                startActivity(i);
            }
        });


        txtfive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Fifth.class);
                startActivity(i);
            }
        });


        txtsix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Sixth.class);
                startActivity(i);
            }
        });


        txtseven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Seven.class);
                startActivity(i);
            }
        });


        txteight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Eight.class);
                startActivity(i);
            }
        });

        txtnine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Ninth.class);
                startActivity(i);
            }
        });


        txtten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Tenth.class);
                startActivity(i);
            }
        });

        txteleven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Eleven.class);
                startActivity(i);
            }
        });


        txttwelve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Twelve.class);
                startActivity(i);
            }
        });

        txtthirteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, thirteen.class);
                startActivity(i);
            }
        });





        ImageView one = (ImageView)findViewById(R.id.one);
        ImageView two = (ImageView)findViewById(R.id.two);
        ImageView three = (ImageView)findViewById(R.id.three);
        ImageView four = (ImageView)findViewById(R.id.four);
        ImageView five = (ImageView)findViewById(R.id.five);
        ImageView six = (ImageView)findViewById(R.id.six);
        ImageView seven = (ImageView)findViewById(R.id.seven);
        ImageView eight = (ImageView)findViewById(R.id.eight);
        ImageView nine = (ImageView)findViewById(R.id.nine);
        ImageView ten = (ImageView)findViewById(R.id.ten);
        ImageView eleven = (ImageView)findViewById(R.id.eleven);
        ImageView twelve = (ImageView)findViewById(R.id.twelve);
        ImageView thirteen = (ImageView)findViewById(R.id.thirteen);
        ImageView fourteen = (ImageView)findViewById(R.id.one);


        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, one.class);
                startActivity(i);

            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Second.class);
                startActivity(i);

            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Third.class);
                startActivity(i);

            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Four.class);
                startActivity(i);

            }
        });


        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Fifth.class);
                startActivity(i);

            }
        });



        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Sixth.class);
                startActivity(i);

            }
        });



        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Seven.class);
                startActivity(i);

            }
        });



        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Eight.class);
                startActivity(i);

            }
        });



        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Ninth.class);
                startActivity(i);

            }
        });



        ten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Tenth.class);
                startActivity(i);

            }
        });



        eleven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Eleven.class);
                startActivity(i);

            }
        });



        twelve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, Twelve.class);
                startActivity(i);

            }
        });



        thirteen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("View ","View all click" );
                Intent i = new Intent(ViewallActivity.this, thirteen.class);
                startActivity(i);

            }
        });


    }
}
